﻿using System;

namespace DependencyInjection
{
	
	// Abstracción de un servicio
	public interface IAlimento
	{
		string Nombre { get; }
	}
}

